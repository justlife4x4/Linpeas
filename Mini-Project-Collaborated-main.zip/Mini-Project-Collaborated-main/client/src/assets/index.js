import download from './download.png';
import h from './h.png';
import preview from './preview.png';

export {
  download,
  h,
  preview,
};
